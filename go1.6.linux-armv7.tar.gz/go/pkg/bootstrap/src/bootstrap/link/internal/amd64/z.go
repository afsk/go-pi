// Do not edit. Bootstrap copy of /usr/local/go/src/cmd/link/internal/amd64/z.go

//line /usr/local/go/src/cmd/link/internal/amd64/z.go:1
package amd64
